#!/bin/bash
# Copyright (C) Parallels, 1999-2009. All rights reserved.
#
# This script restart network inside RedHat like VM.
#

nmcli_reset
/etc/init.d/network restart

exit 0
# end of script
